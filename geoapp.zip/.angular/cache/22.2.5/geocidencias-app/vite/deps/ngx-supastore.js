import { $l as Subscription, Ac as Injector, Al as ɵɵdefineInjectable, Bc as PLATFORM_ID, Bt as computed, Cl as runInInjectionContext, Fn as Injectable, Rc as NgZone, Tl as signal, Ul as Subject, Vl as map, Wi as setClassMetadata, Xl as SafeSubscriber, _l as makeEnvironmentProviders, dl as inject, el as assertInInjectionContext, eu as arrRemove, il as effect, kc as InjectionToken, lu as __read, ml as isSignal, qt as untracked, su as __extends, uu as __spreadArray, vc as DestroyRef, yc as ENVIRONMENT_INITIALIZER } from "./core-CnjN31Cz.js";
import { n as EmptyError, r as EMPTY, t as mergeAll } from "./mergeAll-BicE-S5_.js";
import { i as popNumber, o as popScheduler, r as innerFrom, t as from } from "./from-D9ATb-jx.js";
import { a as filter } from "./http-AfQw_t5U.js";
import { u as isPlatformBrowser } from "./common-Cm9IkDNz.js";
import { n as createClient } from "./dist-B3lO_vCH.js";
// node_modules/rxjs/dist/esm5/internal/scheduler/dateTimestampProvider.js
var dateTimestampProvider = {
	now: function() {
		return (dateTimestampProvider.delegate || Date).now();
	},
	delegate: void 0
};
// node_modules/rxjs/dist/esm5/internal/ReplaySubject.js
var ReplaySubject = function(_super) {
	__extends(ReplaySubject, _super);
	function ReplaySubject(_bufferSize, _windowTime, _timestampProvider) {
		if (_bufferSize === void 0) _bufferSize = Infinity;
		if (_windowTime === void 0) _windowTime = Infinity;
		if (_timestampProvider === void 0) _timestampProvider = dateTimestampProvider;
		var _this = _super.call(this) || this;
		_this._bufferSize = _bufferSize;
		_this._windowTime = _windowTime;
		_this._timestampProvider = _timestampProvider;
		_this._buffer = [];
		_this._infiniteTimeWindow = true;
		_this._infiniteTimeWindow = _windowTime === Infinity;
		_this._bufferSize = Math.max(1, _bufferSize);
		_this._windowTime = Math.max(1, _windowTime);
		return _this;
	}
	ReplaySubject.prototype.next = function(value) {
		var _a = this, isStopped = _a.isStopped, _buffer = _a._buffer, _infiniteTimeWindow = _a._infiniteTimeWindow, _timestampProvider = _a._timestampProvider, _windowTime = _a._windowTime;
		if (!isStopped) {
			_buffer.push(value);
			!_infiniteTimeWindow && _buffer.push(_timestampProvider.now() + _windowTime);
		}
		this._trimBuffer();
		_super.prototype.next.call(this, value);
	};
	ReplaySubject.prototype._subscribe = function(subscriber) {
		this._throwIfClosed();
		this._trimBuffer();
		var subscription = this._innerSubscribe(subscriber);
		var _a = this, _infiniteTimeWindow = _a._infiniteTimeWindow;
		var copy = _a._buffer.slice();
		for (var i = 0; i < copy.length && !subscriber.closed; i += _infiniteTimeWindow ? 1 : 2) subscriber.next(copy[i]);
		this._checkFinalizedStatuses(subscriber);
		return subscription;
	};
	ReplaySubject.prototype._trimBuffer = function() {
		var _a = this, _bufferSize = _a._bufferSize, _timestampProvider = _a._timestampProvider, _buffer = _a._buffer, _infiniteTimeWindow = _a._infiniteTimeWindow;
		var adjustedBufferSize = (_infiniteTimeWindow ? 1 : 2) * _bufferSize;
		_bufferSize < Infinity && adjustedBufferSize < _buffer.length && _buffer.splice(0, _buffer.length - adjustedBufferSize);
		if (!_infiniteTimeWindow) {
			var now = _timestampProvider.now();
			var last = 0;
			for (var i = 1; i < _buffer.length && _buffer[i] <= now; i += 2) last = i;
			last && _buffer.splice(0, last + 1);
		}
	};
	return ReplaySubject;
}(Subject);
// node_modules/rxjs/dist/esm5/internal/scheduler/Action.js
var Action = function(_super) {
	__extends(Action, _super);
	function Action(scheduler, work) {
		return _super.call(this) || this;
	}
	Action.prototype.schedule = function(state, delay) {
		if (delay === void 0) delay = 0;
		return this;
	};
	return Action;
}(Subscription);
// node_modules/rxjs/dist/esm5/internal/scheduler/intervalProvider.js
var intervalProvider = {
	setInterval: function(handler, timeout) {
		var args = [];
		for (var _i = 2; _i < arguments.length; _i++) args[_i - 2] = arguments[_i];
		var delegate = intervalProvider.delegate;
		if (delegate === null || delegate === void 0 ? void 0 : delegate.setInterval) return delegate.setInterval.apply(delegate, __spreadArray([handler, timeout], __read(args)));
		return setInterval.apply(void 0, __spreadArray([handler, timeout], __read(args)));
	},
	clearInterval: function(handle) {
		var delegate = intervalProvider.delegate;
		return ((delegate === null || delegate === void 0 ? void 0 : delegate.clearInterval) || clearInterval)(handle);
	},
	delegate: void 0
};
// node_modules/rxjs/dist/esm5/internal/scheduler/AsyncAction.js
var AsyncAction = function(_super) {
	__extends(AsyncAction, _super);
	function AsyncAction(scheduler, work) {
		var _this = _super.call(this, scheduler, work) || this;
		_this.scheduler = scheduler;
		_this.work = work;
		_this.pending = false;
		return _this;
	}
	AsyncAction.prototype.schedule = function(state, delay) {
		var _a;
		if (delay === void 0) delay = 0;
		if (this.closed) return this;
		this.state = state;
		var id = this.id;
		var scheduler = this.scheduler;
		if (id != null) this.id = this.recycleAsyncId(scheduler, id, delay);
		this.pending = true;
		this.delay = delay;
		this.id = (_a = this.id) !== null && _a !== void 0 ? _a : this.requestAsyncId(scheduler, this.id, delay);
		return this;
	};
	AsyncAction.prototype.requestAsyncId = function(scheduler, _id, delay) {
		if (delay === void 0) delay = 0;
		return intervalProvider.setInterval(scheduler.flush.bind(scheduler, this), delay);
	};
	AsyncAction.prototype.recycleAsyncId = function(_scheduler, id, delay) {
		if (delay === void 0) delay = 0;
		if (delay != null && this.delay === delay && this.pending === false) return id;
		if (id != null) intervalProvider.clearInterval(id);
	};
	AsyncAction.prototype.execute = function(state, delay) {
		if (this.closed) return /* @__PURE__ */ new Error("executing a cancelled action");
		this.pending = false;
		var error = this._execute(state, delay);
		if (error) return error;
		else if (this.pending === false && this.id != null) this.id = this.recycleAsyncId(this.scheduler, this.id, null);
	};
	AsyncAction.prototype._execute = function(state, _delay) {
		var errored = false;
		var errorValue;
		try {
			this.work(state);
		} catch (e) {
			errored = true;
			errorValue = e ? e : /* @__PURE__ */ new Error("Scheduled action threw falsy error");
		}
		if (errored) {
			this.unsubscribe();
			return errorValue;
		}
	};
	AsyncAction.prototype.unsubscribe = function() {
		if (!this.closed) {
			var _a = this, id = _a.id, scheduler = _a.scheduler;
			var actions = scheduler.actions;
			this.work = this.state = this.scheduler = null;
			this.pending = false;
			arrRemove(actions, this);
			if (id != null) this.id = this.recycleAsyncId(scheduler, id, null);
			this.delay = null;
			_super.prototype.unsubscribe.call(this);
		}
	};
	return AsyncAction;
}(Action);
// node_modules/rxjs/dist/esm5/internal/Scheduler.js
var Scheduler = function() {
	function Scheduler(schedulerActionCtor, now) {
		if (now === void 0) now = Scheduler.now;
		this.schedulerActionCtor = schedulerActionCtor;
		this.now = now;
	}
	Scheduler.prototype.schedule = function(work, delay, state) {
		if (delay === void 0) delay = 0;
		return new this.schedulerActionCtor(this, work).schedule(state, delay);
	};
	Scheduler.now = dateTimestampProvider.now;
	return Scheduler;
}();
// node_modules/rxjs/dist/esm5/internal/scheduler/AsyncScheduler.js
var AsyncScheduler = function(_super) {
	__extends(AsyncScheduler, _super);
	function AsyncScheduler(SchedulerAction, now) {
		if (now === void 0) now = Scheduler.now;
		var _this = _super.call(this, SchedulerAction, now) || this;
		_this.actions = [];
		_this._active = false;
		return _this;
	}
	AsyncScheduler.prototype.flush = function(action) {
		var actions = this.actions;
		if (this._active) {
			actions.push(action);
			return;
		}
		var error;
		this._active = true;
		do
			if (error = action.execute(action.state, action.delay)) break;
		while (action = actions.shift());
		this._active = false;
		if (error) {
			while (action = actions.shift()) action.unsubscribe();
			throw error;
		}
	};
	return AsyncScheduler;
}(Scheduler);
// node_modules/rxjs/dist/esm5/internal/scheduler/QueueAction.js
var QueueAction = function(_super) {
	__extends(QueueAction, _super);
	function QueueAction(scheduler, work) {
		var _this = _super.call(this, scheduler, work) || this;
		_this.scheduler = scheduler;
		_this.work = work;
		return _this;
	}
	QueueAction.prototype.schedule = function(state, delay) {
		if (delay === void 0) delay = 0;
		if (delay > 0) return _super.prototype.schedule.call(this, state, delay);
		this.delay = delay;
		this.state = state;
		this.scheduler.flush(this);
		return this;
	};
	QueueAction.prototype.execute = function(state, delay) {
		return delay > 0 || this.closed ? _super.prototype.execute.call(this, state, delay) : this._execute(state, delay);
	};
	QueueAction.prototype.requestAsyncId = function(scheduler, id, delay) {
		if (delay === void 0) delay = 0;
		if (delay != null && delay > 0 || delay == null && this.delay > 0) return _super.prototype.requestAsyncId.call(this, scheduler, id, delay);
		scheduler.flush(this);
		return 0;
	};
	return QueueAction;
}(AsyncAction);
// node_modules/rxjs/dist/esm5/internal/scheduler/queue.js
var queueScheduler = new (function(_super) {
	__extends(QueueScheduler, _super);
	function QueueScheduler() {
		return _super !== null && _super.apply(this, arguments) || this;
	}
	return QueueScheduler;
}(AsyncScheduler))(QueueAction);
// node_modules/rxjs/dist/esm5/internal/firstValueFrom.js
function firstValueFrom(source, config) {
	var hasConfig = typeof config === "object";
	return new Promise(function(resolve, reject) {
		var subscriber = new SafeSubscriber({
			next: function(value) {
				resolve(value);
				subscriber.unsubscribe();
			},
			error: reject,
			complete: function() {
				if (hasConfig) resolve(config.defaultValue);
				else reject(new EmptyError());
			}
		});
		source.subscribe(subscriber);
	});
}
// node_modules/rxjs/dist/esm5/internal/observable/merge.js
function merge() {
	var args = [];
	for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
	var scheduler = popScheduler(args);
	var concurrent = popNumber(args, Infinity);
	var sources = args;
	return !sources.length ? EMPTY : sources.length === 1 ? innerFrom(sources[0]) : mergeAll(concurrent)(from(sources, scheduler));
}
// node_modules/@ngrx/signals/fesm2022/ngrx-signals.mjs
var DEEP_SIGNAL = Symbol(typeof ngDevMode !== "undefined" && ngDevMode ? "DEEP_SIGNAL" : "");
function toDeepSignal(signal) {
	return new Proxy(signal, {
		has(target, prop) {
			return !!this.get(target, prop, void 0);
		},
		get(target, prop) {
			const value = untracked(target);
			if (!isRecord(value) || !(prop in value)) {
				if (isSignal(target[prop]) && target[prop][DEEP_SIGNAL]) delete target[prop];
				return target[prop];
			}
			if (!isSignal(target[prop])) {
				Object.defineProperty(target, prop, {
					value: computed(() => target()[prop]),
					configurable: true
				});
				target[prop][DEEP_SIGNAL] = true;
			}
			return toDeepSignal(target[prop]);
		}
	});
}
var nonRecords = [
	WeakSet,
	WeakMap,
	Promise,
	Date,
	Error,
	RegExp,
	ArrayBuffer,
	DataView,
	Function
];
function isRecord(value) {
	if (value === null || typeof value !== "object" || isIterable(value)) return false;
	let proto = Object.getPrototypeOf(value);
	if (proto === Object.prototype) return true;
	while (proto && proto !== Object.prototype) {
		if (nonRecords.includes(proto.constructor)) return false;
		proto = Object.getPrototypeOf(proto);
	}
	return proto === Object.prototype;
}
function isIterable(value) {
	return typeof value?.[Symbol.iterator] === "function";
}
var STATE_WATCHERS = /* @__PURE__ */ new WeakMap();
var STATE_SOURCE = Symbol(typeof ngDevMode !== "undefined" && ngDevMode ? "STATE_SOURCE" : "");
/**
* @description
*
* Updates the state of a SignalStore or SignalState.
* Accepts a sequence of partial state objects and partial state updaters.
*
* @usageNotes
*
* ```ts
* import { patchState, signalStore, withMethods, withState } from '@ngrx/signals';
*
* export const CounterStore = signalStore(
*   withState({ count1: 0, count2: 0 }),
*   withMethods((store) => ({
*     incrementFirst(): void {
*       patchState(store, (state) => ({ count1: state.count1 + 1 }));
*     },
*     resetSecond(): void {
*       patchState(store, { count2: 0 });
*     },
*   }))
* );
* ```
*/
function patchState(stateSource, ...updaters) {
	const currentState = untracked(() => getState(stateSource));
	const newState = updaters.reduce((nextState, updater) => ({
		...nextState,
		...typeof updater === "function" ? updater(nextState) : updater
	}), currentState);
	const signals = stateSource[STATE_SOURCE];
	const stateKeys = Reflect.ownKeys(stateSource[STATE_SOURCE]);
	for (const key of Reflect.ownKeys(newState)) if (stateKeys.includes(key)) {
		const signalKey = key;
		if (currentState[signalKey] !== newState[signalKey]) signals[signalKey].set(newState[signalKey]);
	} else if (typeof ngDevMode !== "undefined" && ngDevMode) console.warn(`@ngrx/signals: patchState was called with an unknown state slice '${String(key)}'.`, "Ensure that all state properties are explicitly defined in the initial state.", "Updates to properties not present in the initial state will be ignored.");
	notifyWatchers(stateSource);
}
/**
* @description
*
* Returns a snapshot of the current state from a SignalStore or SignalState.
* When used within a reactive context, state changes are automatically tracked.
*
* @usageNotes
*
* ```ts
* import { Component, effect, inject } from '@angular/core';
* import { getState, signalStore, withState } from '@ngrx/signals';
*
* export const CounterStore = signalStore(
*   withState({ count1: 0, count2: 0 })
* );
*
* \@Component(...)
* export class Counter {
*   readonly store = inject(CounterStore);
*
*   constructor() {
*     effect(() => {
*       const state = getState(this.store);
*       // 👇 Logs on state changes.
*       console.log(state);
*     });
*   }
* }
* ```
*/
function getState(stateSource) {
	const signals = stateSource[STATE_SOURCE];
	return Reflect.ownKeys(stateSource[STATE_SOURCE]).reduce((state, key) => {
		const value = signals[key]();
		return {
			...state,
			[key]: value
		};
	}, {});
}
/**
* @description
*
* Synchronously tracks state changes of a SignalStore or SignalState.
*
* @usageNotes
*
* ```ts
* import { Component } from '@angular/core';
* import { signalState, watchState } from '@ngrx/signals';
*
* \@Component(...)
* export class Counter {
*   readonly state = signalState({ count1: 0, count2: 0 });
*
*   constructor() {
*     // 👇 Synchronously logs every state change without debouncing.
*     watchState(this.state, console.log);
*   }
* }
* ```
*/
function watchState(stateSource, watcher, config) {
	if (typeof ngDevMode !== "undefined" && ngDevMode && !config?.injector) assertInInjectionContext(watchState);
	const destroyRef = (config?.injector ?? inject(Injector)).get(DestroyRef);
	addWatcher(stateSource, watcher);
	executeWatcher(stateSource, watcher);
	const destroy = () => removeWatcher(stateSource, watcher);
	destroyRef.onDestroy(destroy);
	return { destroy };
}
function getWatchers(stateSource) {
	return STATE_WATCHERS.get(stateSource[STATE_SOURCE]) || [];
}
function notifyWatchers(stateSource) {
	const watchers = getWatchers(stateSource);
	for (const watcher of watchers) executeWatcher(stateSource, watcher);
}
function executeWatcher(stateSource, stateWatcher) {
	untracked(() => {
		stateWatcher(getState(stateSource));
	});
}
function addWatcher(stateSource, watcher) {
	const watchers = getWatchers(stateSource);
	STATE_WATCHERS.set(stateSource[STATE_SOURCE], [...watchers, watcher]);
}
function removeWatcher(stateSource, watcher) {
	const watchers = getWatchers(stateSource);
	STATE_WATCHERS.set(stateSource[STATE_SOURCE], watchers.filter((w) => w !== watcher));
}
/**
* @description
*
* Creates a store by composing features.
* Returns an injectable service that can be provided locally or globally.
*
* @usageNotes
*
* ```ts
* import { Component, inject } from '@angular/core';
* import { patchState, signalStore, withMethods, withState } from '@ngrx/signals';
*
* export const CounterStore = signalStore(
*   withState({ count: 0 }),
*   withMethods((store) => ({
*     increment(): void {
*       patchState(store, ({ count }) => ({ count: count + 1 }));
*     },
*   }))
* );
*
* \@Component({
*   // ...
*   providers: [CounterStore],
* })
* export class Counter {
*   readonly store = inject(CounterStore);
*
*   logCount(): void {
*     console.log(this.store.count());
*   }
*
*   increment(): void {
*     this.store.increment();
*   }
* }
* ```
*/
function signalStore(...args) {
	const signalStoreArgs = [...args];
	const config = typeof signalStoreArgs[0] === "function" ? {} : signalStoreArgs.shift();
	const features = signalStoreArgs;
	class SignalStore {
		constructor() {
			const innerStore = features.reduce((store, feature) => feature(store), getInitialInnerStore());
			const { stateSignals, props, methods, hooks } = innerStore;
			const storeMembers = {
				...stateSignals,
				...props,
				...methods
			};
			this[STATE_SOURCE] = innerStore[STATE_SOURCE];
			for (const key of Reflect.ownKeys(storeMembers)) this[key] = storeMembers[key];
			const { onInit, onDestroy } = hooks;
			if (onInit) onInit();
			if (onDestroy) inject(DestroyRef).onDestroy(onDestroy);
		}
		/** @nocollapse */ static ɵfac = function SignalStore_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || SignalStore)();
		};
		/** @nocollapse */ static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
			token: SignalStore,
			factory: SignalStore.ɵfac,
			providedIn: config.providedIn || null
		});
	}
	(() => {
		(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SignalStore, [{
			type: Injectable,
			args: [{ providedIn: config.providedIn || null }]
		}], () => [], null);
	})();
	return SignalStore;
}
function getInitialInnerStore() {
	return {
		[STATE_SOURCE]: {},
		stateSignals: {},
		props: {},
		methods: {},
		hooks: {}
	};
}
/**
* @description
*
* Combines multiple store features into a single feature.
*
* @usageNotes
*
* ```ts
* import {
*   patchState,
*   signalStore,
*   signalStoreFeature,
*   withMethods,
*   withState,
* } from '@ngrx/signals';
*
* export function withCounter() {
*   return signalStoreFeature(
*     withState({ count: 0 }),
*     withMethods((store) => ({
*       increment(): void {
*         patchState(store, ({ count }) => ({ count: count + 1 }));
*       },
*     }))
*   );
* }
*
* export const CounterStore = signalStore(withCounter());
* ```
*/
function signalStoreFeature(...args) {
	const features = typeof args[0] === "function" ? args : args.slice(1);
	return (inputStore) => features.reduce((store, feature) => feature(store), inputStore);
}
function assertUniqueStoreMembers(store, newMemberKeys) {
	const storeMembers = {
		...store.stateSignals,
		...store.props,
		...store.methods
	};
	const overriddenKeys = Reflect.ownKeys(storeMembers).filter((memberKey) => newMemberKeys.includes(memberKey));
	if (overriddenKeys.length > 0) console.warn("@ngrx/signals: SignalStore members cannot be overridden.", "Trying to override:", overriddenKeys.map((key) => String(key)).join(", "));
}
/**
* @description
*
* Adds custom properties to a SignalStore.
*
* @usageNotes
*
* ```ts
* import { toObservable } from '@angular/core/rxjs-interop';
* import { signalStore, withProps, withState } from '@ngrx/signals';
*
* export const TodosStore = signalStore(
*   withState({ todos: [] as Todo[], isLoading: false }),
*   withProps(({ isLoading }) => ({
*     isLoading$: toObservable(isLoading),
*   }))
* );
* ```
*/
function withProps(propsFactory) {
	return (store) => {
		const props = propsFactory({
			[STATE_SOURCE]: store[STATE_SOURCE],
			...store.stateSignals,
			...store.props,
			...store.methods
		});
		if (typeof ngDevMode !== "undefined" && ngDevMode) assertUniqueStoreMembers(store, Reflect.ownKeys(props));
		return {
			...store,
			props: {
				...store.props,
				...props
			}
		};
	};
}
/**
* @description
*
* Adds lifecycle hooks to a SignalStore.
* Supports an onInit hook that executes when the store is initialized.
* Supports an onDestroy hook for when the store is destroyed.
*
* @usageNotes
*
* ```ts
* import { signalStore, withHooks, withState } from '@ngrx/signals';
*
* export const UserStore = signalStore(
*   withState({ firstName: 'Jimi', lastName: 'Hendrix' }),
*   withHooks({
*     onInit({ firstName }) {
*       console.log('first name on init', firstName());
*     },
*     onDestroy({ lastName }) {
*       console.log('last name on destroy', lastName());
*     },
*   })
* );
* ```
*/
function withHooks(hooksOrFactory) {
	return (store) => {
		const storeMembers = {
			[STATE_SOURCE]: store[STATE_SOURCE],
			...store.stateSignals,
			...store.props,
			...store.methods
		};
		const hooks = typeof hooksOrFactory === "function" ? hooksOrFactory(storeMembers) : hooksOrFactory;
		const mergeHooks = (currentHook, hook) => {
			return hook ? () => {
				if (currentHook) currentHook();
				hook(storeMembers);
			} : currentHook;
		};
		return {
			...store,
			hooks: {
				onInit: mergeHooks(store.hooks.onInit, hooks.onInit),
				onDestroy: mergeHooks(store.hooks.onDestroy, hooks.onDestroy)
			}
		};
	};
}
/**
* @description
*
* Adds methods to a SignalStore.
*
* @usageNotes
*
* ```ts
* import { patchState, signalStore, withMethods, withState } from '@ngrx/signals';
*
* export const CounterStore = signalStore(
*   withState({ count: 0 }),
*   withMethods((store) => ({
*     increment(): void {
*       patchState(store, ({ count }) => ({ count: count + 1 }));
*     },
*     decrement(): void {
*       patchState(store, ({ count }) => ({ count: count - 1 }));
*     },
*   }))
* );
* ```
*/
function withMethods(methodsFactory) {
	return (store) => {
		const methods = methodsFactory({
			[STATE_SOURCE]: store[STATE_SOURCE],
			...store.stateSignals,
			...store.props,
			...store.methods
		});
		if (typeof ngDevMode !== "undefined" && ngDevMode) assertUniqueStoreMembers(store, Reflect.ownKeys(methods));
		return {
			...store,
			methods: {
				...store.methods,
				...methods
			}
		};
	};
}
/**
* @description
*
* Adds state slices to a SignalStore.
* Accepts an object or a factory function that returns the initial state.
*
* @usageNotes
*
* ```ts
* import { signalStore, withState } from '@ngrx/signals';
*
* export const CounterStore = signalStore(
*   withState({ count: 0 })
* );
* ```
*/
function withState(stateOrFactory) {
	return (store) => {
		const state = typeof stateOrFactory === "function" ? stateOrFactory() : stateOrFactory;
		const stateKeys = Reflect.ownKeys(state);
		if (typeof ngDevMode !== "undefined" && ngDevMode) assertUniqueStoreMembers(store, stateKeys);
		const stateSource = store[STATE_SOURCE];
		const stateSignals = {};
		for (const key of stateKeys) {
			stateSource[key] = signal(state[key]);
			stateSignals[key] = toDeepSignal(stateSource[key]);
		}
		return {
			...store,
			stateSignals: {
				...store.stateSignals,
				...stateSignals
			}
		};
	};
}
// node_modules/@angular/core/fesm2022/rxjs-interop.mjs
/**
* @license Angular v22.2.4
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
function toObservable(source, options) {
	if (ngDevMode && !options?.injector) assertInInjectionContext(toObservable);
	const injector = options?.injector ?? inject(Injector);
	const subject = new ReplaySubject(1);
	const watcher = effect(() => {
		let value;
		try {
			value = source();
		} catch (err) {
			untracked(() => subject.error(err));
			return;
		}
		untracked(() => subject.next(value));
	}, {
		injector,
		manualCleanup: true
	});
	injector.get(DestroyRef).onDestroy(() => {
		watcher.destroy();
		subject.complete();
	});
	return subject.asObservable();
}
// node_modules/@ngrx/signals/fesm2022/ngrx-signals-events.mjs
var EVENTS = Symbol(typeof ngDevMode !== "undefined" && ngDevMode ? "EVENTS" : "");
var SOURCE_TYPE = Symbol(typeof ngDevMode !== "undefined" && ngDevMode ? "SOURCE_TYPE" : "");
var BaseEvents = class {
	/**
	* @internal
	*/
	[EVENTS] = new Subject();
	events$;
	constructor(parentEventsToken) {
		const parentEvents = inject(parentEventsToken, {
			skipSelf: true,
			optional: true
		});
		this.events$ = parentEvents ? merge(parentEvents.events$, this[EVENTS]) : this[EVENTS].asObservable();
	}
	on(...events) {
		return this.events$.pipe(filterByType(events), withSourceType());
	}
};
/**
* @description
*
* Globally provided service for listening to dispatched events.
*
* @usageNotes
*
* ```ts
* import { event, Events } from '@ngrx/signals/events';
*
* const increment = event('[Counter Page] Increment');
*
* \@Component(...)
* class Counter {
*   readonly #events = inject(Events);
*
*   constructor() {
*     this.#events
*       .on(increment)
*       .pipe(takeUntilDestroyed())
*       .subscribe(() => /* handle increment event *\/);
*   }
* }
* ```
*/
var Events = class Events extends BaseEvents {
	constructor() {
		super(Events);
	}
	/** @nocollapse */ static ɵfac = function Events_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || Events)();
	};
	/** @nocollapse */ static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: Events,
		factory: Events.ɵfac,
		providedIn: "platform"
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Events, [{
		type: Injectable,
		args: [{ providedIn: "platform" }]
	}], () => [], null);
})();
/**
* @description
*
* Globally provided service for listening to dispatched events.
* Receives events before the `Events` service and is primarily used for
* handling state transitions.
*/
var ReducerEvents = class ReducerEvents extends BaseEvents {
	constructor() {
		super(ReducerEvents);
	}
	/** @nocollapse */ static ɵfac = function ReducerEvents_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ReducerEvents)();
	};
	/** @nocollapse */ static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: ReducerEvents,
		factory: ReducerEvents.ɵfac,
		providedIn: "platform"
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReducerEvents, [{
		type: Injectable,
		args: [{ providedIn: "platform" }]
	}], () => [], null);
})();
function filterByType(events) {
	if (events.length === 0) return (source$) => source$;
	const eventMap = toEventCreatorMap(events);
	return filter(({ type }) => !!eventMap[type]);
}
function toEventCreatorMap(events) {
	return events.reduce((acc, event) => ({
		...acc,
		[event.type]: event
	}), {});
}
function withSourceType() {
	return map(({ ...event }) => {
		Object.defineProperty(event, SOURCE_TYPE, { value: event.type });
		return event;
	});
}
/**
* @description
*
* Globally provided service for dispatching events.
*
* @usageNotes
*
* ```ts
* import { Dispatcher, event } from '@ngrx/signals/events';
*
* const increment = event('[Counter Page] Increment');
*
* \@Component(...)
* class Counter {
*   readonly #dispatcher = inject(Dispatcher);
*
*   increment(): void {
*     this.#dispatcher.dispatch(increment());
*   }
* }
* ```
*/
var Dispatcher = class Dispatcher {
	reducerEvents = inject(ReducerEvents);
	events = inject(Events);
	parentDispatcher = inject(Dispatcher, {
		skipSelf: true,
		optional: true
	});
	dispatch(event, config) {
		if (this.parentDispatcher && hasParentOrGlobalScope(config)) this.parentDispatcher.dispatch(event, config.scope === "global" ? config : void 0);
		else {
			this.reducerEvents[EVENTS].next(event);
			queueScheduler.schedule(() => this.events[EVENTS].next(event));
		}
	}
	/** @nocollapse */ static ɵfac = function Dispatcher_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || Dispatcher)();
	};
	/** @nocollapse */ static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: Dispatcher,
		factory: Dispatcher.ɵfac,
		providedIn: "platform"
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Dispatcher, [{
		type: Injectable,
		args: [{ providedIn: "platform" }]
	}], null, null);
})();
function hasParentOrGlobalScope(config) {
	return config?.scope === "parent" || config?.scope === "global";
}
// node_modules/@ngrx/signals/fesm2022/ngrx-signals-entities.mjs
var DidMutate;
(function(DidMutate) {
	DidMutate[DidMutate["None"] = 0] = "None";
	DidMutate[DidMutate["Entities"] = 1] = "Entities";
	DidMutate[DidMutate["Both"] = 2] = "Both";
})(DidMutate || (DidMutate = {}));
// node_modules/@angular-architects/ngrx-toolkit/fesm2022/angular-architects-ngrx-toolkit.mjs
function throwIfNull(obj) {
	if (obj === null || obj === void 0) throw new Error("");
	return obj;
}
/**
* Internal Service used by {@link withGlitchTracking}. It does not rely
* on `effect` as {@link DefaultTracker} does but uses the NgRx function
* `watchState` to track all state changes.
*/
var GlitchTrackerService = class GlitchTrackerService {
	#stores = {};
	#callback;
	get stores() {
		return Object.entries(this.#stores).reduce((acc, [id, { store }]) => {
			acc[id] = store;
			return acc;
		}, {});
	}
	onChange(callback) {
		this.#callback = callback;
	}
	removeStore(id) {
		this.#stores = Object.entries(this.#stores).reduce((newStore, [storeId, value]) => {
			if (storeId !== id) newStore[storeId] = value;
			else value.destroyWatcher();
			return newStore;
		}, {});
		throwIfNull(this.#callback)({});
	}
	track(id, store) {
		const watcher = watchState(store, (state) => {
			throwIfNull(this.#callback)({ [id]: state });
		});
		this.#stores[id] = {
			destroyWatcher: watcher.destroy,
			store
		};
	}
	notifyRenamedStore(id) {
		if (Object.keys(this.#stores).includes(id) && this.#callback) this.#callback({ [id]: getState(this.#stores[id].store) });
	}
	static {
		this.ɵfac = function GlitchTrackerService_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || GlitchTrackerService)();
		};
	}
	static {
		this.ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
			token: GlitchTrackerService,
			factory: GlitchTrackerService.ɵfac,
			providedIn: "root"
		});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(GlitchTrackerService, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], null, null);
})();
/**
* Injection token for the configuration options for connecting to the Redux DevTools Extension.
*/
var REDUX_DEVTOOLS_CONFIG = new InjectionToken("ReduxDevtoolsConfig");
var DefaultTracker = class DefaultTracker {
	#stores = signal({}, ...ngDevMode ? [{ debugName: "#stores" }] : []);
	get stores() {
		return this.#stores();
	}
	#trackCallback;
	#trackingEffect = effect(() => {
		if (this.#trackCallback === void 0) throw new Error("no callback function defined");
		const stores = this.#stores();
		const fullState = Object.entries(stores).reduce((acc, [id, store]) => {
			return {
				...acc,
				[id]: getState(store)
			};
		}, {});
		this.#trackCallback(fullState);
	}, ...ngDevMode ? [{ debugName: "#trackingEffect" }] : []);
	track(id, store) {
		this.#stores.update((value) => ({
			...value,
			[id]: store
		}));
	}
	onChange(callback) {
		this.#trackCallback = callback;
	}
	removeStore(id) {
		this.#stores.update((stores) => Object.entries(stores).reduce((newStore, [storeId, state]) => {
			if (storeId !== id) newStore[storeId] = state;
			return newStore;
		}, {}));
	}
	notifyRenamedStore(id) {
		if (this.#stores()[id]) this.#stores.update((stores) => {
			return { ...stores };
		});
	}
	static {
		this.ɵfac = function DefaultTracker_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || DefaultTracker)();
		};
	}
	static {
		this.ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
			token: DefaultTracker,
			factory: DefaultTracker.ɵfac,
			providedIn: "root"
		});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DefaultTracker, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], null, null);
})();
var currentActionNames = /* @__PURE__ */ new Set();
var dummyConnection = { send: () => void 0 };
/**
* A service provided by the root injector is
* required because the synchronization runs
* globally.
*
* The SignalStore could be provided in a component.
* If the effect starts in the injection
* context of the SignalStore, the complete sync
* process would shut down once the component gets
* destroyed.
*/
var DevtoolsSyncer = class DevtoolsSyncer {
	/**
	* Stores all SignalStores that are connected to the
	* DevTools along their options, names and id.
	*/
	#stores = {};
	#isBrowser = isPlatformBrowser(inject(PLATFORM_ID));
	#trackers = [];
	#devtoolsConfig = {
		name: "NgRx SignalStore",
		...inject(REDUX_DEVTOOLS_CONFIG, { optional: true })
	};
	/**
	* Maintains the current states of all stores to avoid conflicts
	* between glitch-free and glitched trackers when used simultaneously.
	*
	* The challenge lies in ensuring that glitched trackers do not
	* interfere with the synchronization process of glitch-free trackers.
	* Specifically, glitched trackers could cause the synchronization to
	* read the current state of stores managed by glitch-free trackers.
	*
	* Therefore, the synchronization process doesn't read the state from
	* each store, but relies on #currentState.
	*
	* Please note, that here the key is the name and not the id.
	*/
	#currentState = {};
	#currentId = 1;
	#connection = inject(NgZone).runOutsideAngular(() => this.#isBrowser ? window.__REDUX_DEVTOOLS_EXTENSION__ ? window.__REDUX_DEVTOOLS_EXTENSION__.connect(this.#devtoolsConfig) : dummyConnection : dummyConnection);
	constructor() {
		if (!this.#isBrowser) return;
	}
	ngOnDestroy() {
		currentActionNames.clear();
	}
	syncToDevTools(changedStatePerId) {
		const mappedChangedStatePerName = Object.entries(changedStatePerId).reduce((acc, [id, store]) => {
			const { options, name } = this.#stores[id];
			acc[name] = options.map(store);
			return acc;
		}, {});
		this.#currentState = {
			...this.#currentState,
			...mappedChangedStatePerName
		};
		const names = Array.from(currentActionNames);
		const type = names.length ? names.join(", ") : "Store Update";
		currentActionNames.clear();
		this.#connection.send({ type }, this.#currentState);
	}
	getNextId() {
		return String(this.#currentId++);
	}
	/**
	* Consumer provides the id. That is because we can only start
	* tracking the store in the init hook.
	* Unfortunately, methods for renaming having the final id
	* need to be defined already before.
	* That's why `withDevtools` requests first the id and
	* then registers itself later.
	*/
	addStore(id, name, store, options) {
		let storeName = name;
		const names = Object.values(this.#stores).map((store) => store.name);
		if (names.includes(storeName)) {
			if (!options.indexNames) throw new Error(`An instance of the store ${storeName} already exists. \
Enable automatic indexing via withDevTools('${storeName}', { indexNames: true }), or rename it upon instantiation.`);
		}
		for (let i = 1; names.includes(storeName); i++) storeName = `${name}-${i}`;
		this.#stores[id] = {
			name: storeName,
			options
		};
		const tracker = options.tracker;
		if (!this.#trackers.includes(tracker)) this.#trackers.push(tracker);
		tracker.onChange((changedState) => this.syncToDevTools(changedState));
		tracker.track(id, store);
	}
	removeStore(id) {
		const name = this.#stores[id].name;
		this.#stores = Object.entries(this.#stores).reduce((newStore, [storeId, value]) => {
			if (storeId !== id) newStore[storeId] = value;
			return newStore;
		}, {});
		this.#currentState = Object.entries(this.#currentState).reduce((newState, [storeName, state]) => {
			if (storeName !== name) newState[storeName] = state;
			return newState;
		}, {});
		for (const tracker of this.#trackers) tracker.removeStore(id);
	}
	/**
	* Renames a store identified by its internal id. If the store has already
	* been removed (e.g. due to component destruction), this is a no-op.
	*/
	renameStore(id, newName) {
		const storeEntry = this.#stores[id];
		if (!storeEntry) return;
		const oldName = storeEntry.name;
		if (oldName === newName) return;
		if (Object.entries(this.#stores).filter(([entryId]) => entryId !== id).map(([, s]) => s.name).includes(newName)) throw new Error(`NgRx Toolkit/DevTools: cannot rename from ${oldName} to ${newName}. ${newName} is already assigned to another SignalStore instance.`);
		this.#stores = Object.entries(this.#stores).reduce((newStore, [entryId, value]) => {
			if (entryId === id) newStore[entryId] = {
				...value,
				name: newName
			};
			else newStore[entryId] = value;
			return newStore;
		}, {});
		this.#currentState = Object.entries(this.#currentState).reduce((newState, [storeName, state]) => {
			if (storeName !== oldName) newState[storeName] = state;
			return newState;
		}, {});
		this.#trackers.forEach((tracker) => tracker.notifyRenamedStore(id));
	}
	static {
		this.ɵfac = function DevtoolsSyncer_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || DevtoolsSyncer)();
		};
	}
	static {
		this.ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
			token: DevtoolsSyncer,
			factory: DevtoolsSyncer.ɵfac,
			providedIn: "root"
		});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DevtoolsSyncer, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], () => [], null);
})();
var renameDevtoolsMethodName = "___renameDevtoolsName";
var uniqueDevtoolsId = "___uniqueDevtoolsId";
var DEVTOOL_FEATURE_NAMES = Symbol("DEVTOOL_PROP");
/**
* Adds this store as a feature state to the Redux DevTools.
*
* By default, the action name is 'Store Update'. You can
* change that via the {@link updateState} method, which has as second
* parameter the action name.
*
* The standalone function {@link renameDevtoolsName} can rename
* the store name.
*
* @param name name of the store as it should appear in the DevTools
* @param features features to extend or modify the behavior of the Devtools
*/
function withDevtools(name, ...features) {
	return signalStoreFeature(withMethods(() => {
		const syncer = inject(DevtoolsSyncer);
		const id = syncer.getNextId();
		return {
			[renameDevtoolsMethodName]: (newName) => {
				syncer.renameStore(id, newName);
			},
			[uniqueDevtoolsId]: () => id
		};
	}), withProps(() => ({ [DEVTOOL_FEATURE_NAMES]: features.filter(Boolean).map((f) => f.name) })), withHooks((store) => {
		const syncer = inject(DevtoolsSyncer);
		const id = String(store[uniqueDevtoolsId]());
		return {
			onInit() {
				const finalOptions = {
					indexNames: !features.some((f) => f.indexNames === false),
					map: features.find((f) => f.map)?.map ?? ((state) => state),
					tracker: inject(features.find((f) => f.tracker)?.tracker || DefaultTracker)
				};
				syncer.addStore(id, name, store, finalOptions);
			},
			onDestroy() {
				syncer.removeStore(id);
			}
		};
	}));
}
/**
* Wrapper of `patchState` for DevTools integration. Next to updating the state,
* it also sends the action to the DevTools.
* @param stateSource state of Signal Store
* @param action name of action how it will show in DevTools
* @param updaters updater functions or objects
*/
function updateState(stateSource, action, ...updaters) {
	currentActionNames.add(action);
	return patchState(stateSource, ...updaters);
}
var keyPath = "ngrxToolkitKeyPath";
var dbName = "ngrxToolkitDb";
var storeName = "ngrxToolkitStore";
var VERSION = 1;
var IndexedDBService = class IndexedDBService {
	/**
	* write to indexedDB
	* @param key
	* @param data
	*/
	async setItem(key, data) {
		const db = await this.openDB();
		const tx = db.transaction(storeName, "readwrite");
		tx.objectStore(storeName).put({
			[keyPath]: key,
			value: data
		});
		return new Promise((resolve, reject) => {
			tx.oncomplete = () => {
				db.close();
				resolve();
			};
			tx.onerror = () => {
				db.close();
				reject();
			};
		});
	}
	/**
	* read from indexedDB
	* @param key
	*/
	async getItem(key) {
		const db = await this.openDB();
		const request = db.transaction(storeName, "readonly").objectStore(storeName).get(key);
		return new Promise((resolve, reject) => {
			request.onsuccess = () => {
				db.close();
				if (request.result === void 0) resolve(null);
				resolve(request.result?.["value"]);
			};
			request.onerror = () => {
				db.close();
				reject();
			};
		});
	}
	/**
	* delete indexedDB
	* @param key
	*/
	async clear(key) {
		const db = await this.openDB();
		const request = db.transaction(storeName, "readwrite").objectStore(storeName).delete(key);
		return new Promise((resolve, reject) => {
			request.onsuccess = () => {
				db.close();
				resolve();
			};
			request.onerror = () => {
				db.close();
				reject();
			};
		});
	}
	/**
	* open indexedDB
	*/
	async openDB() {
		return new Promise((resolve, reject) => {
			const request = indexedDB.open(dbName, VERSION);
			request.onupgradeneeded = () => {
				const db = request.result;
				if (!db.objectStoreNames.contains(storeName)) db.createObjectStore(storeName, { keyPath });
			};
			request.onsuccess = () => {
				resolve(request.result);
			};
			request.onerror = () => {
				reject(request.error);
			};
		});
	}
	static {
		this.ɵfac = function IndexedDBService_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || IndexedDBService)();
		};
	}
	static {
		this.ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
			token: IndexedDBService,
			factory: IndexedDBService.ɵfac,
			providedIn: "root"
		});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(IndexedDBService, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], null, null);
})();
var LocalStorageService = class LocalStorageService {
	getItem(key) {
		return localStorage.getItem(key);
	}
	setItem(key, data) {
		return localStorage.setItem(key, data);
	}
	clear(key) {
		return localStorage.removeItem(key);
	}
	static {
		this.ɵfac = function LocalStorageService_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || LocalStorageService)();
		};
	}
	static {
		this.ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
			token: LocalStorageService,
			factory: LocalStorageService.ɵfac,
			providedIn: "root"
		});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LocalStorageService, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], null, null);
})();
var SessionStorageService = class SessionStorageService {
	getItem(key) {
		return sessionStorage.getItem(key);
	}
	setItem(key, data) {
		return sessionStorage.setItem(key, data);
	}
	clear(key) {
		return sessionStorage.removeItem(key);
	}
	static {
		this.ɵfac = function SessionStorageService_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || SessionStorageService)();
		};
	}
	static {
		this.ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
			token: SessionStorageService,
			factory: SessionStorageService.ɵfac,
			providedIn: "root"
		});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SessionStorageService, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], null, null);
})();
signalStoreFeature(withState({}));
// node_modules/ngxtension/fesm2022/ngxtension-assert-injector.mjs
function assertInjector(fn, injector, runner) {
	!injector && assertInInjectionContext(fn);
	const assertedInjector = injector ?? inject(Injector);
	if (!runner) return assertedInjector;
	return runInInjectionContext(assertedInjector, runner);
}
// node_modules/ngxtension/fesm2022/ngxtension-create-injection-token.mjs
function createInjectFn(token) {
	return function({ injector, ...injectOptions } = {}) {
		injector = assertInjector(this, injector);
		return runInInjectionContext(injector, () => inject(token, injectOptions));
	};
}
function createProvideFn(token, factory, opts = {}) {
	const { deps = [], multi = false, extraProviders = [], isFunctionValue: isFunctionValueFromOpts = false } = opts;
	return (value, isFunctionValue = isFunctionValueFromOpts) => {
		let provider;
		if (typeof value !== "undefined") provider = {
			provide: token,
			useFactory: typeof value === "function" ? isFunctionValue ? () => value : value : () => value,
			multi
		};
		else provider = {
			provide: token,
			useFactory: factory,
			deps,
			multi
		};
		return [extraProviders, provider];
	};
}
/**
* `createInjectionToken` accepts a factory function and returns a tuple of `injectFn`, `provideFn`, and the `InjectionToken`
* that the factory function is for.
*
* @param {Function} factory - Factory Function that returns the value for the `InjectionToken`
* @param {CreateInjectionTokenOptions} options - object to control how the `InjectionToken` behaves
* @returns {CreateInjectionTokenReturn}
*
* @example
* ```ts
* const [injectCounter, provideCounter, COUNTER] = createInjectionToken(() => signal(0));
*
* export class Counter {
*  counter = injectCounter(); // WritableSignal<number>
* }
* ```
*/
function createInjectionToken(factory, options) {
	const tokenName = factory.name || factory.toString();
	const opts = options ?? { isRoot: true };
	opts.isRoot ??= true;
	if (opts.multi) opts.isRoot = false;
	if (opts.isRoot) {
		if (opts.token) throw new Error(`\
createInjectionToken is creating a root InjectionToken but an external token is passed in.
`);
		const token = new InjectionToken(`Token for ${tokenName}`, { factory: () => {
			if (opts.deps && Array.isArray(opts.deps)) return factory(...opts.deps.map((dep) => {
				dep = Array.isArray(dep) ? dep.at(-1) : dep;
				return inject(dep);
			}));
			return factory();
		} });
		const injectFn = createInjectFn(token);
		return [
			injectFn,
			createProvideFn(token, factory, opts),
			token,
			() => ({
				provide: ENVIRONMENT_INITIALIZER,
				useValue: () => injectFn(),
				multi: true
			})
		];
	}
	const token = opts.token || new InjectionToken(`Token for ${tokenName}`);
	return [
		createInjectFn(token),
		createProvideFn(token, factory, opts),
		token,
		() => []
	];
}
// node_modules/ngx-supastore/fesm2022/ngx-supastore.mjs
var SUPABASE_OPTIONS = new InjectionToken("SUPABASE_OPTIONS");
var INITIAL_STATE = new InjectionToken("SupastoreState", { factory: () => {
	const { createClient: { supabaseUrl, supabaseAnonKey, options } } = inject(SUPABASE_OPTIONS);
	return {
		client: createClient(supabaseUrl, supabaseAnonKey, options),
		auth: {
			session: void 0,
			user: void 0,
			metadata: void 0,
			state: {
				prev: null,
				curr: null
			}
		}
	};
} });
var withPostAuth = () => signalStoreFeature({ state: void 0 }, withMethods((store, { metadataRpc: rpc, metadataTable: table } = inject(SUPABASE_OPTIONS)) => ({ _postAuth: async () => {
	if (table || rpc) {
		const session = await firstValueFrom(toObservable(store.auth.session).pipe(filter((res) => res !== void 0)));
		if (!session) return;
		if (table) {
			const { data } = await store.client().from(table).select("*").eq("id", session?.user?.id).single();
			updateState(store, "Load Metadata - Table", { auth: {
				...store.auth(),
				metadata: data
			} });
		} else if (rpc) {
			const { data } = await store.client().rpc(rpc, { input: { user_id: session?.user?.id } });
			updateState(store, "Load Metadata - Rpc", { auth: {
				...store.auth(),
				metadata: data
			} });
		} else updateState(store, "No Metadata", { auth: {
			...store.auth(),
			metadata: null
		} });
	}
} })), withHooks({ onInit(store) {
	store._postAuth();
} }));
var withSupastoreCore = () => signalStoreFeature(withDevtools("supastore"), withState(() => inject(INITIAL_STATE)), withPostAuth(), withProps(({ auth: { user, session, metadata } }) => ({
	user$: toObservable(user).pipe(filter((res) => res !== void 0)),
	session$: toObservable(session).pipe(filter((res) => res !== void 0)),
	metadata$: toObservable(metadata).pipe(filter((res) => res !== void 0))
})), withMethods((store) => ({
	_initSession: async () => {
		const { data: { session }, error } = await store.client().auth.getSession();
		updateState(store, "Initialise Session", { auth: {
			...store.auth(),
			session
		} });
	},
	_initUser: async () => {
		const { data: { user }, error } = await store.client().auth.getUser();
		updateState(store, "Initialise User", { auth: {
			...store.auth(),
			user
		} });
	}
})), withHooks({ onInit(store) {
	store.client().auth.onAuthStateChange((state) => {
		updateState(store, "Auth State Change", { auth: {
			...store.auth(),
			state: {
				prev: store.auth.state.curr(),
				curr: state
			}
		} });
	});
	store._initSession();
	store._initUser();
} }));
var Supastore = signalStore(withSupastoreCore());
var provideSupastore = (options) => makeEnvironmentProviders([{
	provide: SUPABASE_OPTIONS,
	useValue: options
}, Supastore]);
var [injectSupaClient] = createInjectionToken(() => inject(Supastore)["client"]);
var [injectSupaAuth] = createInjectionToken(() => inject(Supastore)["auth"]);
export { Supastore, injectSupaAuth, injectSupaClient, provideSupastore, withSupastoreCore };
